﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace StoredProcedure
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true) //Loops the code
            {
                bool legalInput = true;
                string connectionString;
                connectionString = "Server = localhost; Database = PagesContainer; Integrated Security = True; ";
                Console.Write("1, 2 or 3: ");
                int input = 0;
                int.TryParse(Console.ReadLine(), out input); //The input is used for the switch case
                string sql = "SELECT CAST(PersonID AS nvarchar) + ' ' + TRIM(FirstName) + ' ' + TRIM(LastName) + ' ' + CAST(Age AS nvarchar) FROM [Persons]";
                SqlDataReader dataReader = null;
                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand command = null;
                switch (input) //Switches between three different connection methods
                {
                    case 1: //Uses SQL code in the dB
                        Console.WriteLine("SQL code method!");
                        conn.Open();
                        command = new SqlCommand(sql, conn);
                        break;

                    case 2: //Uses a stored procedure
                        Console.WriteLine("Procedure method!");
                        command = new SqlCommand("SelectAllPersons", conn);
                        command.CommandType = CommandType.StoredProcedure;
                        conn.Open();
                        break;

                    case 3: //Uses a stored procedure with a name parameter.
                        Console.WriteLine("Procedure with paremeter method!");
                        command = new SqlCommand("SelectPersonByName", conn);
                        command.CommandType = CommandType.StoredProcedure;
                        Console.Write("Name: ");
                        string ParameterName = Console.ReadLine(); //Takes in a string as a name
                        command.Parameters.Add(new SqlParameter("@Name", ParameterName));
                        conn.Open();
                        break;

                    default: //If 1, 2 or 3 is not put in, as a precaution for errors
                        legalInput = false;
                        break;
                }
                if (legalInput) //default turns this false, if input is not 1, 2 or 3
                {
                    command.ExecuteNonQuery();
                    dataReader = command.ExecuteReader();
                    while (dataReader.Read())
                    {
                        Console.WriteLine(dataReader.GetString(0));
                    }
                    conn.Close();
                }
                Console.WriteLine(""); //For space
            }
        }
    }
}